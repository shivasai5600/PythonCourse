""" =================================== random module ======================================================

=>'random' is one of the pre-defined module
=>The purpose of random module is that to 'To generate random values in various ways'.

============ random module contains the following functions =======================
             1) randint(start,stop)----random value btw start and stop inclusive
         Ex: import random
             print(random.randint(10,20)) ---------------- output: 13
 -----------------------------------------------------------------------------------------------------------
             2)randrange(start,stop)---start<=randomvalue<stopvalue
        Ex: import random
             print(random.randeange(10,20)) ---------------- output: 13
 ------------------------------------------------------------------------------------------------------------
             3)random()     ------------------ 0.0 to 1.0
             4)uniform()    ------------------ start,stop-----integer/floats--------floating values
             5)choice()
             6)shuffle()
             7)sample()
"""