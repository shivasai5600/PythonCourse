import random
print(random.randint(10,20)) #here 20 no. is inclusive
print("="*30)

print(random.randrange(10,20)) #here 20 no. is not included
print("="*30)

print(random.random())
print("%0.2f" %random.random())
print(round(random.random(),2))
print("="*30)

for i in range(1,11):
    print(random.uniform(10.5,11.4))
print("="*30)

print(random.choice("python"))
d="123N&#@*^!njksdiWN62849DGYTJ"
print(random.choice(d),random.choice(d),random.choice(d))
print("="*30)

print(random.sample(d,5))
s1=""
s1=s1.join(random.sample(d,6))
print(s1)
print("="*30)

lst=[12,34,53,65,23,54,67,8,867,855,6,75]
print("Original List Values:",lst)
print("-"*25)
for l in range(1,6):
    random.shuffle(lst)
    print(lst)

