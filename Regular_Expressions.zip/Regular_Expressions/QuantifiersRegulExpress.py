""""======================================================================================================================
                               Quantifiers in Regular Expressions
========================================================================================================================
->Quantifiers in Regular Expressions are used for searching number of occurrens of the specified value (specified
  alphabets or digits or special symbols) used in searched pattern to search in the given data and obtains desired output

1. 'k' ------- searches for only 'k' at a time
2. 'k+' ------ it searches for either one 'k' more 'k's
3. 'k*' ------ it search for either zero 'k' or mor 'k' and more 'k's
4. 'k?' ------ it search for either zero 'k' or one 'k'
5. '.' ------- it searches for all

NOTE :
------
1. \dd or d{3} ------ searches for 3 digits
2. \dd.\dd ---------- searches for 2 integer values or 2 decimal values
3. \d{2,4} ---------- searches for min 2 digits num and max 4 digit num
4. [A-Za-z]+ -------- searches one alphabet or more alphabets


"""


# 1.
import re
matchtab = re.finditer("k", "akaakkaakkkaka")
for i in matchtab:
    print("Start Index: {} End Index: {} Value: {}".format(i.start(),i.end(),i.group()))

print("="*50)
# 2.
matchtab = re.finditer("k*", "akaakkaakkkaka")
for i in matchtab:
    print("Start Index: {} End Index: {} Value: {}".format(i.start(),i.end(),i.group()))

print("=" * 50)
# 3.
matchtab = re.finditer("k+", "akaakkaakkkaka")
for i in matchtab:
    print("Start Index: {} End Index: {} Value: {}".format(i.start(),i.end(),i.group()))

print("="*50)
# 4.
matchtab = re.finditer("k?", "akaakkaakkkaka")
for i in matchtab:
    print("Start Index: {} End Index: {} Value: {}".format(i.start(),i.end(),i.group()))

print("="*50)
# 5. This program searches for all
matchtab = re.finditer(".", "aka33akk45aakkkaka")
for i in matchtab:
    print("Start Index: {} End Index: {} Value: {}".format(i.start(),i.end(),i.group()))