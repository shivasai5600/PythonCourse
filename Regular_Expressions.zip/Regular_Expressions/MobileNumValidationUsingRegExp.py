# Write a program which will evaluate mobile number using Regular Expression

import re
while(True):
    num = input("Enter the mobile number: ")
    if (len(num) == 10):
        result = re.search(r"\d{10}",num)
        if (result!=None):
            print(num, "is a valid mobile number")
            break
    else:
        print("{}, which u have entered is not containing 10 digits".format(num))