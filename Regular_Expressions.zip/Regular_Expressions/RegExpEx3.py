import re
gd="Python is an oop lang. Python is also Functional Programming lang"
sp="lang"
matchlist=re.findall(sp,gd)           # findall()
print("No of Occurrences: '{}' is {}".format(sp,len(matchlist)))
