import re
gd="Python is an oop lang. Python is also Functional Programming lang"
sp="Python"
lp="an"
count=0
noc=0
mtab = re.finditer(sp,gd)
ntab = re.finditer(lp,gd)
for i in mtab:
    print("="*50)
    count += 1
    print("Start Index: {}\nEnd Index: {}\nValue: {}".format(i.start(),i.end(),i.group()))
else:
    print("="*50)
    print("Number of Occurences of '{}' is {}".format(sp,count))

print("="*50)
for j in ntab:
    print("="*50)
    noc=noc+1
    print("Start Index: {} End Index: {} Value: {}".format(j.start(),j.end(),j.group()))
else:
    print("="*50)
    print("Number of Occurences of '{}' is {}".format(lp, noc))

