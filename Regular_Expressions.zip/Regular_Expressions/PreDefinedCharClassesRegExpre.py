"""=======================================================================================================================
                    Pre -  Defined Character Classes in Regular Expressions
========================================================================================================================
->The Purpose of Pre - Defined Character Classes in Regular Expressions are available in Python software as
  pre - defined API
->The Purpose of pre-defined Character Classes in Regular Expressions to prepare Search patterns to search in the
  given data for obtaing desired output

Syntax :    '\pre-defined character class'

1. \s ------- searches for only space character
2. \S ----- searches all except space character
3. \w ----- searching for all word characters except special symbols
4. \W ----- searches for special symbols (except alpha-numericals)
5. \d ----- searches for digits only
6. \D ----- searches all except digits
7.
8.
9.
10.
11.
12.

"""

# 1. Program for searching for space character
import re
matchtab = re.finditer('\s',"c AhjUYH12 biu&98t")
for i in matchtab:
    print("Start INdex: {} End Index: {} Value: {}".format(i.start(),i.end(),i.group()))

print("="*50)
#2. Program for searching all except for space character
import re
matchtab = re.finditer("\S","c AhjUYH12 biu&98t")
for i in matchtab:
    print("Start INdex: {} End Index: {} Value: {}".format(i.start(),i.end(),i.group()))

print("="*50)
#3. Program for searching for all word characters except special symbols
import re
matchtab = re.finditer("\w","c AhjUYH12 biu&98t")
for i in matchtab:
    print("Start INdex: {} End Index: {} Value: {}".format(i.start(),i.end(),i.group()))

print("="*50)
#4. Program for searches for special symbols (except alpha-numericals)
import re
matchtab = re.finditer("\W","c AhjUYH12 biu&98t")
for i in matchtab:
    print("Start INdex: {} End Index: {} Value: {}".format(i.start(),i.end(),i.group()))

print("="*50)
#5. Program for searches for digits only
import re
matchtab = re.finditer("\d","c AhjUYH12 biu&98t")
for i in matchtab:
    print("Start INdex: {} End Index: {} Value: {}".format(i.start(),i.end(),i.group()))

print("="*50)
#6. Program for searches all except digits
import re
matchtab = re.finditer("\D","c AhjUYH12 biu&98t")
for i in matchtab:
    print("Start INdex: {} End Index: {} Value: {}".format(i.start(),i.end(),i.group()))