import re
gd="Python is an oop lang. Python is also Functional Programming lang"
sp="is"
matchlist=re.search(sp,gd)           # search()
if matchlist!=None:
    print("'{}' is Found ".format(sp))
else:
    print("'{}' does not found".format(sp))
