# This program searching Names and Marks of Students Using RegEx in given data

import re
gd = ("Rohit got 56 marks , Raman got 77 marks Rocky got 88 marks  Ganesh got 99 marks Anuj got 67 marks , Raju got 57 marks Rraj got 59 marks , Raman got 77 marks ")
namelist = re.findall("[A-Za-z]+",gd)
print("="*50)
print("Name of Students: ")
print("="*50)
for name in namelist:
    print("\t{}".format(name))
print("="*50)
markslist = re.findall(r"\d{2}",gd)
print("Marks of Students:")
print("="*50)
for marks in markslist:
    print("\t{}".format(marks))
print("="*50)
print("Student Names\tStudent Marks")
print("="*50)
for sn,sm in zip(namelist,markslist):
    print("\t{}\t{}".format(sn,sm))


print("="*50)
print("="*50)

# This program searches Names and Marks of Students Using RegEx in given data

# import re
#
# gd = ("Rohit got 56 marks , Raman got 77 marks Rocky got 88 marks  Ganesh got 99 marks "
#       "Anuj got 67 marks , Raju got 57 marks Rraj got 59 marks , Raman got 77 marks ")
#
# namelist = re.findall(r"([A-Z][a-z]+)\s+got", gd)  # Extract names before "got"
#
# print("=" * 50)
# print("Name of Students: ")
# print("=" * 50)
# for name in namelist:
#     print("\t{}".format(name))
#
# print("=" * 50)
# markslist = re.findall(r"\d{2}", gd)
# print("Marks of Students:")
# print("=" * 50)
# for marks in markslist:
#     print("\t{}".format(marks))
#
# print("=" * 50)
# print("Student Names\tStudent Marks")
# print("=" * 50)
#
# for i, sn in enumerate(namelist):
#     print("\t{}\t{}".format(sn, markslist[i]))
#
# print("=" * 50)
