import re
gd="Python is an oop lang. Python is also Functional Programming lang"
sp="Python"
lp="lang"
mtab = re.finditer(sp,gd)
ntab = re.finditer(lp,gd)
for i in mtab:
    print("Start Index: {}\nEnd Index: {}\nValue: {}".format(i.start(),i.end(),i.group()))
print("="*50)
for j in ntab:
    print("Start Index: {} End Index: {} Value: {}".format(j.start(),j.end(),j.group()))

