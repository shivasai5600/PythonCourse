#This Program Searches alphabets/symbols only for the given pattern, here a,b,c
import re
matchtab = re.finditer("[abc]","cAaU#2RQk8%b6^WoP")
for onematch in matchtab:
    print("Start Index: {} End Index: {} Value Index:{}".format(onematch.start(),onematch.end(),onematch.group()))

#This Program Searches except alphabets/symbols only for the given pattern, here a,b,c remainnig will give output
print("="*50)
matchtab = re.finditer("[^abc]","cAaU#2RQk8%b6^WoP")
for onematch in matchtab:
    print("Start Index: {} End Index: {} Value Index:{}".format(onematch.start(),onematch.end(),onematch.group()))

#This Program Searches alphabets/symbols only lower
print("="*50)
matchtab = re.finditer("[a-z]","cAaU#2RzQk8%b6^WoP")
for onematch in matchtab:
    print("Start Index: {} End Index: {} Value Index:{}".format(onematch.start(),onematch.end(),onematch.group()))

#This Program Searches alphabets/symbols only lower except a-z
print("="*50)
matchtab = re.finditer("[^a-z]","cAaU#2RzQk8%b6^WoP")
for onematch in matchtab:
    print("Start Index: {} End Index: {} Value Index:{}".format(onematch.start(),onematch.end(),onematch.group()))

#This Program Searches alphabets/symbols of upper case A-Z
print("="*50)
matchtab = re.finditer("[A-Z]","cAaU#2RzQk8%b6^WoP")
for onematch in matchtab:
    print("Start Index: {} End Index: {} Value Index:{}".format(onematch.start(),onematch.end(),onematch.group()))

#This Program Searches alphabets/symbols except of upper case A-Z
print("="*50)
matchtab = re.finditer("[^A-Z]","cAaU#2RzQk8%b6^WoP")
for onematch in matchtab:
    print("Start Index: {} End Index: {} Value Index:{}".format(onematch.start(),onematch.end(),onematch.group()))

#This Program Searches al alphabets of upper case A-Z and lower case of a-z
print("="*50)
matchtab = re.finditer("[A-Za-z]","cAaU#2RzQk8%b6^WoP")
for onematch in matchtab:
    print("Start Index: {} End Index: {} Value Index:{}".format(onematch.start(),onematch.end(),onematch.group()))


#This Program Searches except alphabets of upper case A-Z and lower case of a-z
print("="*50)
matchtab = re.finditer("[^A-Za-z]","cAaU#2RzQk8%b6^WoP")
for onematch in matchtab:
    print("Start Index: {} End Index: {} Value Index:{}".format(onematch.start(),onematch.end(),onematch.group()))

#This Program Searches all digits only 0-9
print("="*50)
matchtab = re.finditer("[0-9]","cAaU#2RzQk8%b6^WoP")
for onematch in matchtab:
    print("Start Index: {} End Index: {} Value Index:{}".format(onematch.start(),onematch.end(),onematch.group()))

#This Program Searches all except digits only 0-9
print("="*50)
matchtab = re.finditer("[^0-9]","cAaU#2RzQk8%b6^WoP")
for onematch in matchtab:
    print("Start Index: {} End Index: {} Value Index:{}".format(onematch.start(),onematch.end(),onematch.group()))

#This Program Searches all alpha-numericals only 0-9,a-z,A-Z (except symbols)
print("="*50)
matchtab = re.finditer("[0-9A-Za-z]","cAaU#2RzQk8%b6^WoP")
for onematch in matchtab:
    print("Start Index: {} End Index: {} Value Index:{}".format(onematch.start(),onematch.end(),onematch.group()))

#This Program Searches specisl symbols except alpha-numericals only 0-9,a-z,A-Z
print("="*50)
matchtab = re.finditer("[^0-9A-Za-z]","cAaU#2RzQk8%b6^WoP")
for onematch in matchtab:
    print("Start Index: {} End Index: {} Value Index:{}".format(onematch.start(),onematch.end(),onematch.group()))

















