# This program searching Names and Marks of Students info by reading text documentation from file(studentinfo.data9)

import re
try:
    with open("studentsinfo.data","r") as fp:
        filedata = fp.read()
        namelist=re.findall("[A-za-z]+",filedata)
        marklist=re.findall(r"d{2}",filedata)
        print("="*50)
        print("Student Names\tStudent Marks")
        print("="*50)
        for sn,sm in zip(namelist,marklist):
            print("\t{}\t{}".format(sn,sm))
except FileNotFoundError as e:
    print("File does not exist",e)

print("="*50)
print("="*50)

try:
    with open("mailsinfo.data","r") as fp:
        filedata = fp.read()
        namelist=re.finditer(r"\S+@\S+",filedata)
        print("="*50)
        print("Start INdex\tEnd Index\tValue")
        print("="*50)
        for mail in namelist:
            print("\t\t",mail.start(),"\t",mail.end(),"\t",mail.group())
        print("="*50)
        print("Student Mails:")
        for i in namelist:
            print("\t{}".format(i.group()))         # only gives mails output,here it is not displying bcz readinf once
        print("="*50)                               # of finditer
except FileNotFoundError as e:
    print("File does not exist",e)
