import re
gd=input("Enter a line of Text: ")
sp=input("Enter which word u want to search: ")
matchlist=re.search(sp,gd)           # search()
if matchlist!=None:
    print("'{}' is Found ".format(sp))
else:
    print("'{}' does not found".format(sp))