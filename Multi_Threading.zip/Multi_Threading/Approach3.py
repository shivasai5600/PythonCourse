# Approach3 program
import threading,time

class Sample:
    def show(self):
        print("Name of Child Thread=",threading.current_thread().name)  #Thread -1
        print("show() of Sample")
        print("We Write Thread based Logic")

#main program
print("Number of main thread=",threading.current_thread().name)   #main thread
s=Sample()
t1=threading.Thread(target=s.show())
t1.name = "Sss"
t1.start()