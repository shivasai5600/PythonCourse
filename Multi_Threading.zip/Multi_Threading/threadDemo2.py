import threading
def hello():
    tname1 = threading.current_thread().name
    print("\nHello executed by {}".format(tname1))
    print("Im from Hello()")

def hi():
    tname2 = threading.current_thread().name
    print("\nHi executed by {}".format(tname2))
    print("Im from Hi()")

def hel():
    tname3 = threading.current_thread().name
    print("\nHel executed by {}".format(tname3))
    print("Im from Hel()")

#main program
dftname = threading.current_thread().name
print("\nDefault Name of thread in main program = {}".format(dftname))
hello()
hi()
hel()

