import threading
class Train:
    L=threading.Lock()
    def __init__(self,n):
        self.seats=n

    def reservation(self,nos):
        self.L.acquire()
        if(nos>self.seats):
            print("{} unable to get {} seats:".format(threading.current_thread().name,nos))
        else:
            self.seats=self.seats-nos
            print("{} Reserved {} seats:".format(threading.current_thread().name, nos))
        self.L.release()

# amin program

t=Train(int(input("Enter the Number of Seats:")))
t1=threading.Thread(target=t.reservation,args=(100,))
t2=threading.Thread(target=t.reservation,args=(15,))
t3=threading.Thread(target=t.reservation,args=(20,))
t4=threading.Thread(target=t.reservation,args=(17,))

# dispatch the program
t1.start()
t2.start()
t3.start()
t4.start()