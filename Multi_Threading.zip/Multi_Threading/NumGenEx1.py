# Program will display 1 to n numbers by using threads with OOPs (Inheritence)

import time
from threading import Thread

class Numbers(Thread):
    def run(self):       #overridden run()
        n=int(input("Enter Number of Numbers generate:"))
        if(n<=0):
            print("{} is invalid input".format(n))
        else:
            print("Number within:{}".format(n))
            for i in range(1,n+1):
                print("Val of i={}".format(i))
                time.sleep(1)

#main program
n = Numbers() #creating child thread
n.start()