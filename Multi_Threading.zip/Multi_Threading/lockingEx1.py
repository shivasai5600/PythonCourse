import threading
import time

def multable(n):
    k.acquire()  # step -2
    print("=" * 50)
    print("Child Thread Name =", threading.current_thread().name)
    print("Mul Table for {} ".format(n))
    for i in range(1, 11):
        print("{} x {} = {}".format(n, i, n * i))
        time.sleep(1)
    print("=" * 50)
    k.release()  # step - 3

# main Program
k = threading.Lock()  # ✅ Create an instance of Lock

t1 = threading.Thread(target=multable, args=(5,))
t2 = threading.Thread(target=multable, args=(15,))
t3 = threading.Thread(target=multable, args=(19,))
t4 = threading.Thread(target=multable, args=(7,))

t1.start()
t2.start()
t3.start()
t4.start()
