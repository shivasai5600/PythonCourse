import time,threading

def squares(lst):
    tname1 = threading.current_thread().name
    print("\nSquares() executed by {}".format(tname1))
    for val in lst:
        print("Square({}) is {}".format(val,val**2))
        time.sleep(1)
def cubes(lst):
    tname2 = threading.current_thread().name
    print("\nCube() executed by {}".format(tname2))
    for val in lst:
        print("Cube({}) is {}".format(val,val**3))
        time.sleep(1)

# main program
bt=time.time()
dftname = threading.current_thread().name
print("\nDefault Name of thread in main program = {}".format(dftname))
lst=[2,4,6,8,-5,7]
squares(lst)
cubes(lst)
at=time.time()
print("Time taken to execute the program {} - {} is {}".format(at,bt,at-bt))