# Program generating multiple table by using thread (using functional approach)

import threading,time

def multable(n):
    tname=threading.current_thread().name
    print("Name of Child Thread in multable()={}".format(tname))
    if(n<=0):
        print("{} is invalid input".format(n))
    else:
        print("="*50)
        print("Mul Table of {}".format(n))
        print("="*50)
        for i in range(1,11):
            print(f"\t{n} x {i} = {n*i}")
            time.sleep(2)
        print("="*50)

#main program

print("Number of Active Threads in this Program before Start =",threading.active_count())
t1 = threading.Thread(target=multable,args=(19,))
print("Default Child Thread Name=",t1.name)        #getting child thread name
t1.name = "HYD"                                    #setting user-friendly thread name
print("Execution status of t1 before start=",t1.is_alive()) #False
t1.start()
print("Execution status of t1 after start=",t1.is_alive())  #True
print("Number of Active Threads in this Program =",threading.active_count())
t1.join()
print("Execution status of t1 after completion=",t1.is_alive())

