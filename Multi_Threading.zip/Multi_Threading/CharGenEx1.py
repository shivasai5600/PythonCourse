import threading,time
def chargeneration():
    line = input("ENter a line of text:")
    print("="*50)
    print("GIven Line:{}".format(line))
    print("=" * 50)
    for ch in line:
        print("\t\t{}".format(ch))
        time.sleep(1)
    print("="*50)

#main program
t1 = threading.Thread(target=chargeneration())
t1.start()