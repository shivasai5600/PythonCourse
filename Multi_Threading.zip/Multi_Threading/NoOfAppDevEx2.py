import threading,time

def generate(n):
    print("NUmber of Numbers:{}".format(n))
    ctname=threading.current_thread().name
    print("Name of Child Thread",ctname)
    print("="*50)
    for i in range(1,n+1):
        print("\tValue of i={}".format(i))
        time.sleep(1)
    print("="*50)

#main program
mtname = threading.current_thread().name
print("Name of main thread={}".format(mtname))
t1=threading.Thread(target=generate,args=(10,)) #creating child thread
t1.name="sss"
t1.start()     #distaching child thread
print("Number of active threads =", threading.active_count())
t1.join()
print("Line - 21,Number of active threads =", threading.active_count())