import threading
import time

# class Character:
#     def genchar(self, line):
#         l = list(line)
#         print("=" * 50)
#         print("Given Line: {}".format(line))
#         print("=" * 50)
#         for ch in line:
#             print("\t\tCharacter : {} and Occurrences: {}".format(ch, l.count(ch)))
#             time.sleep(1)
#         print("=" * 50)
#
# # Main program
# line = input("Enter a line: ")
# t1 = threading.Thread(target=Character().genchar, args=(line,))
# t1.start()


                        # for REVERSE of LINE program (Run Reach Program Once/Not at a time)

class Characterr:
    def gencharr(self, line):
        l = list(line)
        print("=" * 50)
        print("Given Line: {}".format(line))
        print("=" * 50)
        for ch in line[::-1]:
            print("\t\tCharacterr : {} and Occurrences: {}".format(ch, l.count(ch)))
            time.sleep(1)
        print("=" * 50)

# Main program
line = input("Enter a line: ")
t1 = threading.Thread(target=Characterr().gencharr, args=(line,))
t1.start()