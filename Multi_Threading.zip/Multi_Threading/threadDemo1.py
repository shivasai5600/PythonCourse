import threading
tname1 = threading.current_thread().name
print("Hello executed by {}".format(tname1))
print("Im from Hello()")