import threading,time
def chargeneration():
    line = input("ENter a line of text:")
    l=list(line)
    print("="*50)
    print("GIven Line:{}".format(line))
    print("=" * 50)
    for ch in line:
        print("\t\tCharacter : {} and Occurences:{}".format(ch,l.count(ch)))
        time.sleep(1)
    print("="*50)

#main program
t1 = threading.Thread(target=chargeneration())
t1.start()