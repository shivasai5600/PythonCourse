# Approach2 program
import threading,time

class Hyd(threading.Thread):
    def run(self):
        print("im from run()")
        print("Thread based Application")

#main program
print("Number of main thread=",threading.current_thread().name)
h=Hyd()
print("Here Execution status of 'h' before start=",h.is_alive())
h.start()
print("Here Execution status of 'h' after start=",h.is_alive())