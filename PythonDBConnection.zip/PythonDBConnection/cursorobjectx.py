#This Program get the connection and creates cursor object
import cx_Oracle #step-1
con=cx_Oracle.connect("user1/1234@localhost/orcl")     #step-2
print("Python Program obtained connection Oracle Db")
cur=con.cursor()  #step-3
print("\nType of cur variable=",type(cur)) #Type of cur variable=<class, cx_Oracle.Connection.Cursor>
print("Cursor Object Created")