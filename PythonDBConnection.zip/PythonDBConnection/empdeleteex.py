#This deletes the record from employee table
import cx_Oracle
try:
    con=cx_Oracle.connect("user1/1234@localhost/orcl")
    cur=con.cursor()
    #design the query and execute
    cur.execute("delete from employee where eno=333")
    con.commit()
    if(cur.rowcount>0):
        print("Employee Record removed")
    else:
        print("Employee record does not exists")
except cx_Oracle.DatabaseError as db:
    print("Problem in DataBase:",db)
