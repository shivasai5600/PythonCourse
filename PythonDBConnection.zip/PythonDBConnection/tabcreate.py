#This program creates a table from python Program in Oracle DB
import cx_Oracle
con=cx_Oracle.connect("user1/1234@localhost/orcl")
cur=con.cursor()
#design and execute the query
qry="create table employee(eno number(3) primary key,name varchar2(10) not null,sal number(5,2) not null)"
cur.execute(qry)
print("\nTable created successfully in Oracle DB")
