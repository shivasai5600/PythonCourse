#This Program obtains Connection from Oracle DataBase
import cx_Oracle    #step-1
try:
    con=cx_Oracle.connect("user1/1234@localhost/orcl")     #step-2
    print("\nType of con var=",type(con))     #Type of con var=<class 'cx_Oracle.Connector'>
    print("Python Program got Connection from Oracle DB")
except cx_Oracle.DatabaseError as db:
    print("Problem in Connection",db)
finally:
    con.close()
    print("\nPython closes the connection from Oracle DB")


#=====================================  OR ===================================================
import cx_Oracle    #step-1
try:
    con=cx_Oracle.connect("user1/1234@127.0.0.1/orcl")     #step-2
    print("\nType of con var=",type(con))     #Type of con var=<class 'cx_Oracle.Connector'>
    print("Python Program got Connection from Oracle DB")
except cx_Oracle.DatabaseError as db:
    print("Problem in Connection",db)
finally:
    con.close()
    print("\nPython closes the connection from Oracle DB")