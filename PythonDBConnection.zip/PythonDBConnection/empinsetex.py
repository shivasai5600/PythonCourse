#This accept the values of employee and insert into employee table
import cx_Oracle
try:
    con=cx_Oracle.connect("user1/1234@localhost/orcl")
    cur=con.cursor()
    #design the query and execute
    qry="insert into employee values(444,'DR',4.7,'BELL LABS')"
    cur.execute(qry)
    con.commit()
    print("Employee Record inserted in employee table")
except cx_Oracle.DatabaseError as db:
    print("Problem in DataBase:",db)
