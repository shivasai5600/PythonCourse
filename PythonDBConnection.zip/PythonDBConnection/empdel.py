#This program accept employee number from KBD and Remove employee Record
import cx_Oracle
def deleteemployee():
    try:
        con=cx_Oracle.connect("user1/1234@localhost/orcl")
        cur=con.cursor()
        #design the query and execute
        empno = int(input("Enter Employee Number:"))
        cur.execute("delete from employee where eno=%d" %empno)
        if(cur.rowcount>0):
            print("EMployee Record removed")
        else:
            print("Employee Record does not exists")
    except cx_Oracle.DatabaseError as db:
        print("Problem in Database:",db)