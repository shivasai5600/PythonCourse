#This program alters(modify col names) a table from python Program in Oracle DB
import cx_Oracle
con=cx_Oracle.connect("user1/1234@localhost/orcl")
cur=con.cursor()
#design and execute the query
qry="alter table teacher modify(tno number(4))"
cur.execute(qry)
print("\nEmployee Table altered--verify in Oracle DB")



#This program alters(adding new col names) a table from python Program in Oracle DB
try:
    import cx_Oracle
    con=cx_Oracle.connect("user1/1234@localhost/orcl")
    cur=con.cursor()
#design and execute the query
    qry="alter table teacher add(new sub varchar2(10))"
    cur.execute(qry)
    print("\nEmployee Table altered--verify in Oracle DB")
except cx_Oracle.DatabaseError as db:
    print("Problem in DataBase:",db)