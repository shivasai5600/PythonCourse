""" ==============================Order Of Handling Exceptions ============================================
==>When we handle any exceptions in python program,it is mandatory to handle Specific Exceptions In any Order
   (ValueError,TypeError,IndexError..etc) and at last we must write general exception block with base class exception
   name(Exception or Base Exception) (or) except block without any exception name.Otherwise we get error as
   "SyntaxError: deafult'except:' must be last"

----------------------------------------Syntax:---------------------------------------
try:
   ---------------
   ---------------
except exception-class-name-1:    #specific except block
   -----------------------
except exception-class-name-2:    #specific except block
   -----------------------
           --
           --
except exception-class-name-n:    #specific except block
   -----------------------
except Exception/Base Exception:    #except block with base exception
   -----------------------
except :                           #default exception block
   -------------------------

========================================EXAMPLE ==============================================
----------------------------------Example for syntax--1----------------------------------------
try:
    s1=input("Enter first value:")        # Exception Monitoring block
    s2=input("Enter second value:")
    a=int(s1)
    b=int(s2)
    c=a/b
    s="PYTHON"
    print(s[20])
except ValueError:
    print("\nDon't enter strs/symbols/aipha-numericals")
except ZeroDivisionError:                         # Exception Processing block
    print("\nDon't enter zero for Dneominator")
except IndexError:
    print("\nString Index Out Of Range--chek the index")
except Exception as e:
    print("OOPs something went wrong")
except :
    print("something went wrong take care")
else:                                                           # Exception generating Block
    print("="*50)
    print("Val of a=",a)
    print("Val of b=",b)
    print("Div=",c)
    print("="*50)
finally:
    print("\nIam from finally block")            #it will executes irrespective of exception blocks
"""