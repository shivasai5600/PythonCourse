""" ================ Types of Exception in Python ==========================================================

==> IN python Programming, we have two types of Exceptions .They are:
    1)Pre-defined (or) Built-in Exceptions
    2)Programmer(or)User(or)Custom defined Exceptions
--------------------------------------------------------------------------------------------------
1) Pre-defined (or) Built-in Exceptions:

   ->These Exceptions are already developed (or) defined in Python Software/API,and they are dealing with "Universal Problems"
   ->Some of the Universal Problems are:
     a)Division By Zero Problems(ZeroDivisionError)
     b)Invalid Number Format(ValueError)
     c)Invalid Arguments Passing(TypeError)
     d)No Valid Key in Dict object(KeyError)
     e)Invalid Index In Indexing Operations(IndexError)...etc
----------------------------------------------------------------------------------------------------
2)Programmer(or)User(or)Custom defined Exceptions:

  ->These Exceptions are developed by Python Programmer and they are available in Python Projects and they are used By
    Other Python Programmers for dealing  with "Common Problems".
  ->Some of "Common Problems" are:
    a)Attempting to enter Invalid PIn in ATM Based Applications(PinError)
    b)Attempting to enter Invalid UserName/Password(LoginError)
    c)Attempting to WithDraw more Amount than existing Balance(InSufficientBalanceError)
    d)Attempting to Insert the card in reverse order..etc(InsertError)

==> Handling the exceptions in python is nothing but converting Techincal Error Messages into User-Friendly Messages.
    To do this Python Programming Provides % kry words.They are:
    1) try
    2) except
    3) else
    4) finally
    5) raise
----------------------------------------------------------------
Syntax for handling the exceptions:
-----------------------------------------------------------------
   try:
      Block of statements generates exceptions in python program
   except exception class-name-1:
      Block of statements generates user-friendly Error Messages
   except exception class-name-2:
      Block of statements generates user-friendly Error Messages
                        -------
                        -------
   except exception class-name-n:
      Block of statements generates user-friendly Error Messages
   else:
      Block of statements recommended to generates Results
   finally:
      Block of statements execution compalsarily

"""
# ================================= EXAMPLES ============================================================
# Program for accepting two integer values and find their division
try:
    s1=input("Enter first value:")        # Exception Monitoring block
    s2=input("Enter second value:")
    a=int(s1)
    b=int(s2)
    c=a/b
except ZeroDivisionError:                         # Exception Processing block
    print("\nDon't enter zero for Dneominator")
except ValueError:
    print("\nDon't enter str / Symbols / alpha-numericals")
else:                                                           # Exception generating Block
    print("="*50)
    print("Val of a=",a)
    print("Val of b=",b)
    print("Div=",c)
    print("="*50)
finally:
    print("\nIam from finally block")            #it will executes irrespective of exception blocks