# from atmmenu import atmmenu
# from banking import *
# import sys
# def sbi():
#     while(True):
#         atmmenu()
#         try:
#             ch=int(input("Enter your choice:"))
#             match(ch):
#                case 1:
#                  try:
#                      deposit()
#                  except ValueError:
#                      print("\nDon't Deposit str/symbols/alpha-numericals in ur Account")
#                  except DepositError:
#                      print("\nDon't Deposit -ve and zero Value in ur Account")
#                case 2:
#                  try:
#                      Withdraw()
#                  except ValueError:
#                      print("\nDon't Deposit str/symbols/alpha-numericals in ur Account")
#                  except WithdrawError:
#                      print("\nDon't withdraw -ve and zero Value in ur Account")
#                  except InsufficientError:
#                      print("\nU Don't have sufficient funds")
#                case 3:
#                  BalEnquiry()
#                case 4:
#                  print("\nThanks for using the ATM app")
#                  sys.exit()
#                case _:
#                  print("Ur selection of Operation is wrong-try again")
#         except ValueError:
#             print("\nDon't Enter str/symbols/alpha-numericals")

from atmmenu import atmmenu
from banking import *
import sys

def sbi():
    while True:
        atmmenu()
        try:
            ch = int(input("Enter your choice: "))
            match ch:  # requires Python 3.10+
                case 1:
                    try:
                        deposit()
                    except ValueError:
                        print("\nDon't deposit str/symbols/alpha-numericals in your account")
                    except DepositError:
                        print("\nDon't deposit negative or zero value")
                case 2:
                    try:
                        Withdraw()
                    except ValueError:
                        print("\nDon't withdraw str/symbols/alpha-numericals")
                    except WithdrawError:
                        print("\nDon't withdraw negative or zero value")
                    except InsufficientError:
                        print("\nYou don't have sufficient funds")
                case 3:
                    BalEnquiry()
                case 4:
                    print("\nThanks for using the ATM app")
                    sys.exit()
                case _:
                    print("Invalid operation selection. Try again.")
        except ValueError:
            print("\nDon't enter str/symbols/alpha-numericals")
