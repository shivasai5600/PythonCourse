from runproject import runatm
runatm()