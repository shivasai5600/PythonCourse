from bankexception import DepositError,WithdrawError,InsufficientError
bal=500.00 #global variable
def deposit():
    dmat=float(input("Enter how much amount you want to deposit:")) #ValuError
    if(dmat<=0):
        raise DepositError
    else:
        global bal
        bal=bal+dmat
        print("Ur Account xxxxxxxxxxx123 credited with INR:{}".format(dmat))
        print("Now Ur Current Bal INR:{}".format(bal))

def Withdraw():
    global bal
    wmat=float(input("Enter how much amount u want to withdraw:")) #ValueError
    if(wmat<=0):
        raise WithdrawError
    elif((wmat+500)>bal):
        raise InsufficientError
    else:
        bal=bal-wmat
        print("Ur Account xxxxxxxxxxx123 debited with INR:{}".format(wmat))
        print("Now Ur current Balance INR:{}".format(bal))

def BalEnquiry():
    print("Now Ur current Balance INR:{}".format(bal))

