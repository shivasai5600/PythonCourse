""" ========================================= ATM OPERATIONS ===========================================
1.Deposit
2.Withdraw
3.Bal Enquiry
4.Exit

==>Files need to impliment the above application
---------------------------------------------------------
atmmenu.py----------interface
Banking Operation------deposit, withdraw,bal enq
main program
"""
def atmmenu():
    print("="*50)
    print("\tATM Operations")
    print("=" * 50)
    print("\t1.Deposit")
    print("\t2.Withdraw")
    print("\t3.Bal_Enquiry")
    print("\t4.Exit")
    print("=" * 50)