# import getpass,sys
# from atmmain import sbi
# def runatm():
#     ctr=0
#     while(True):
#         pin=getpass.getpass(prompt="Enter ur Pin:")
#         if(pin=="1234"):
#             sbi()
#         else:
#             print("Ur Pin is invalid,try again")
#             ctr=ctr+1
#             if(ctr==3):
#                 print("Ur card is blocked")
#                 sys.exit()

import getpass
import sys
from atmmain import sbi

def runatm():
    ctr = 0
    while True:
        pin = input("Enter your PIN: ")
      # pin = getpass.getpass("Enter your PIN: ") some times it not works
        if pin == "1234":
            sbi()
        else:
            print("Invalid PIN. Try again.")
            ctr += 1
            if ctr == 3:
                print("Your card is blocked")
                sys.exit()
