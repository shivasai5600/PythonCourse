""" ===================== 2)Programmer(or)User(or)Custom defined Exceptions ============================

->These Exceptions are developed by Python Programmer and they are available in Python Projects and they are used By
    Other Python Programmers for dealing  with "Common Problems".
  ->Some of "Common Problems" are:
    a)Attempting to enter Invalid PIn in ATM Based Applications(PinError)
    b)Attempting to enter Invalid UserName/Password(LoginError)
    c)Attempting to WithDraw more Amount than existing Balance(InSufficientBalanceError)
    d)Attempting to Insert the card in reverse order..etc(InsertError)
===================================================================================================================
               Steps for Developing Programmer Defined Exceptions:
===================================================================================================================
1)Choose the programmer Defined Class Name
2)The Programmer Defined Class name must Inherit from pre-defined exception super class called "Exception or
  Base Exception".Hence programmer defined class becomes programmer defined exception class.
3)Save the above code on file name with an extension .py

Example : Define a programmer-Defined exception class"PinError"
        class PinError(Exception):pass

Example : Define a programmer-Defined exception class"LoginError"
        class LoginError(BaseException):pass
=====================================================================================================================
raise: (keyword)
==>raise is a keyword which is used for raising (or) hitting (or) generating exception as part of Function body
   certain condition is satisfied.
Syntax:
   def function name(list of formal parameters if any):
       -------------------
       -------------------
       if(Test condi):
          raise <exception cass name>
=====================================================================================================================
@Example(Question) : Develop a programmer-Defined exception class name, which works like zeroDivisionError

==>TO Develop any python based application with Programmer-Defined exceptions,we must follow 3 phases.They are
==> 3 Phases

1.Develop Programmer Defined Exception Class Name.
------------------------------Example---------------------------

      #kvr.py -----------File Name acts as the Module Name ----(3)
      #(1)              (2)
 class KvrDivisionError(Exception):pass
-------------------------------------------------------------------------------
2.Develop a common function,In which we Hit/raise the exception.

       #div.py --------File Name acts as the Module Name
       from kvr import KvrDivisionError
       def division(a,b):
           if(b==0):
              raise KvrDivisionError
           else:
              return(a/b)
----------------------------------------------------------------------------------
3.Develop a main program for handling the exceptions
#main program

#divdemo.py -------------
from div import division
from kvr import KvrDivisionError
try:
   x=int(input("Enter first value:"))
   y=int(input("Enter second value:"))
   res=division(x,y)----------------------#calling function
except Exception as f:
    print("Don't enter str/symbols",f)
except KvrDivisionError:
   print("Don't enter zero for Denominator")
else:
   print("Result={}".format(res))
finally:
   print("\nIam from finally block")



"""