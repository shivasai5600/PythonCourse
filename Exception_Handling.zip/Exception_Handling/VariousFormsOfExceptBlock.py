""" ======================= Various forms of Except Blocks =================================================
==> In Python Programming,we can use except block in various forms.They are:
----------syntax -1-----
try:
   ---------
   ---------
except exception-class-name-1:
   ----------------
except exception-class-name-2:
   ---------------
->This syntax handles one exception at a time
----------------------------------Example for syntax--1----------------------------------------
try:
    s1=input("Enter first value:")        # Exception Monitoring block
    s2=input("Enter second value:")
    a=int(s1)
    b=int(s2)
    c=a/b
except ZeroDivisionError:                         # Exception Processing block
    print("\nDon't enter zero for Dneominator")
except ValueError:
    print("\nDon't enter str / Symbols / alpha-numericals")
else:                                                           # Exception generating Block
    print("="*50)
    print("Val of a=",a)
    print("Val of b=",b)
    print("Div=",c)
    print("="*50)
finally:
    print("\nIam from finally block")            #it will executes irrespective of exception blocks
==============================================================================================================
----------syntax -2-----
try:
   ---------
   ---------
except (exception-class-name-1,exception-class-name-2,......,exception-class-name-n):
   ----------------------------
   ----------------------------
->THis syntax handles multiple specific exceptions by using single except block.
----------------------------------Example for syntax--2----------------------------------------
try:
    s1=input("Enter first value:")        # Exception Monitoring block
    s2=input("Enter second value:")
    a=int(s1)
    b=int(s2)
    c=a/b
except (ZeroDivisionError,ValueError):                         # Multi exception handling block
    print("\nDon't enter zero for Dneominator")
    print("\nDon't enter str / Symbols / alpha-numericals")
else:                                                           # Exception generating Block
    print("="*50)
    print("Val of a=",a)
    print("Val of b=",b)
    print("Div=",c)
    print("="*50)
finally:
    print("\nIam from finally block")            #it will executes irrespective of exception blocks
==================================================================================================================
----------syntax -3-----
try:
   ---------
   ---------
except exception-class-name-1 as alias name:
    print(alias name)
except exception-class-name-2 as alias name:
   print(alias name)
->This syntax handles one exception at a time and stores technical error messages in alias name generated due to
  exception occurance
----------------------------------Example for syntax--3----------------------------------------
try:
    s1=input("Enter first value:")        # Exception Monitoring block
    s2=input("Enter second value:")
    a=int(s1)
    b=int(s2)
    c=a/b
except ZeroDivisionError as k:                         # Exception Processing block
    print(k)
except ValueError as n:
    print(n)
else:                                                           # Exception generating Block
    print("="*50)
    print("Val of a=",a)
    print("Val of b=",b)
    print("Div=",c)
    print("="*50)
finally:
    print("\nIam from finally block")            #it will executes irrespective of exception blocks
==============================================================================================================
----------syntax -4-----
try:
   ---------
   ---------
except exception:
   print("OOPs something went wrong")
->This syntax handles all types of exception and but unable generates user-friendly error messages
----------------------------------Example for syntax--4----------------------------------------
try:
    s1=input("Enter first value:")        # Exception Monitoring block
    s2=input("Enter second value:")
    a=int(s1)
    b=int(s2)
    c=a/b
except exception:                         # Exception Processing block
    print("OOps somehting went wrong")
else:                                                           # Exception generating Block
    print("="*50)
    print("Val of a=",a)
    print("Val of b=",b)
    print("Div=",c)
    print("="*50)
==================================================================================================================
----------syntax -5-----
try:
   ---------
   ---------
except : # default except block
   ----------------------------
   ----------------------------
->THis syntax handles all types exceptions in exceptions in except block and it is not recommended bcz end-user
  not getting user-friendly error messages.
----------------------------------Example for syntax--5----------------------------------------
try:
    s1=input("Enter first value:")        # Exception Monitoring block
    s2=input("Enter second value:")
    a=int(s1)
    b=int(s2)
    c=a/b
except :                         # Exception Processing block
    print("Don't")
else:                                                           # Exception generating Block
    print("="*50)
    print("Val of a=",a)
    print("Val of b=",b)
    print("Div=",c)
    print("="*50)
==================================================================================================================
"""
