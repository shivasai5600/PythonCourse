from div import division
from kvr import KvrDivisionError
try:
    x=int(input("Enter first value:"))
    y=int(input("Enter second value:"))
    res=division(x,y)
except KvrDivisionError:
    print("Don't enter zero as Denominator")
except Exception as f:
    print("Don't enter str/symbols",f)
else:
    print("Result={}".format(res))
finally:
    print("\nIam from finally block")