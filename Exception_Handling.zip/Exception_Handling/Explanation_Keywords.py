""" ============= Explanation for the keywords in handling the exceptions ===================
---------------------------------------------------------------------------------------------------------------------
1)try:
==>it is a block,In which we write block of statements generating exceptions.In other words,what are all the statements are
   generating exceptions, those statements must be written within try block and it is known as exception monitering block.
==>When the exception occurs in try block,PVM comes out of the try block and exceutes appropriate except block and
   generates User-Friendly error message.
==>After executing except block, PVM never comes to try block to execute the rest of the statements.
==>Every try block must contain atleast one except block and it is recommended to write multiple except blocks for
   generating multiple user-friendly error messages.
==>Every try block must be immediately followed by except block(otherwise we get syntax error)
---------------------------------------------------------------------------------------------------------------------
2)except:
==>It is in which we write block of statements displays User-Friendly error meassages.In otherwords,except block will
   supresses the Technical error messages and displays User-Friendly error messages and except block is called
   exception processing block.
==>Note: Handling the exception = try block + except block
==>except block will execute when an except occurs in try block
==>Even we write multiple except block,PVM can execute only one except block depends on type of exception occurs
   in try block.
==>we must use the except block after the try block and before else block
-------------------------------------------------------------------------------------------------------------------
3)esle:
==>It is block,in which we write block of statements recommended to displays Result of the python program
   (Result Generating Block).
==>else block will execute when there is no exception occurs in try block
==>Writing else block is an optional.
==>we write else block after except block and before finally block.
---------------------------------------------------------------------------------------------------------------------
4)finally:
==>It is a block,In which we write block of statements for Reqlinquishing(Closing or releasing or give-up or clean-up)
   the resources(files,databases) which are obtained in try block.[known as Resources Reqlinquishing Block]
==>finally block will execute Compulsorily(if we write)
==>writing the finally block is optional
==>We write finally block after else block
--------------------------------------------------------------------------------------------------------------------
5)raise:
==>raise is a keyword which is used for raising (or) hitting (or) generating exception as part of Function body
   certain condition is satisfied.
Syntax:
   def function name(list of formal parameters if any):
       -------------------
       -------------------
       if(Test condi):
          raise <exception cass name>
"""