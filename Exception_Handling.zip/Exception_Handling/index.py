""" ============================INDEX==========================================
==> The purpose of exception handling is that "To built Robust(strong) applications"
==> Purpose of Exception Handling
==> Types of Errors
    a) Compile Time Errors
    b) Logical Errors
    c) Runtime Errors
==> Definition of Exception
==> Definition of Exception Handling
==> Types of Exceptions
    a) Pre-defined Exceptions
    b) Programmer/User/Custom Defined Exceptions
==> Keywords Used in Exception Handling
    1) try
    2) except
    3) else
    4) finally
    5) raise
==> Synatx for Handing the exceptions
==> Programming Examples
==> Development programmer/User/Custom Defined Exceptions
==> Programming Examples
==> ATM Case Study
==============================================================================================================
==> TO develop any real time project, we must use a language.By the language,we develop , compile and execute various
    programs.During this process, we get Various eroors.They are classified into 3 types:
    a) Compile Time Error:
      ==> Compile time error are those which occuring during compile time.
             (.py --->.pyc)
      ==> Compile time error occurs due to syntaxes are not followed by programmer.
      ==> Compile time errors solved by Programmers at Development Level.
             Example: a=10,b=20
                      c=a+


    b) Logical Error:
      ==> Logical Errors are those which occuring during Execution/runtime
      ==> Logical Errors are occurs due to wrong representation of Logic
      ==> Logical Errors always gives wrong result and they solved by the programmers at development time.
              Example: a=10,b=20
                       c=a+b/2 #but expected a+b total divided by 2
    c) Run Time Error:
      ==> RunTime Errors are those which occuring during Execution/runtime
      ==> RunTIme Errors are occurs due to wrong/Invalid inputs entered by the End/Application Users
      ==> RunTime Errors are addressed by Programmers during development time.
              Example: a=10,b=0
                       c=a/b #Zerodivisionerror: zero not divides number, user not understands this level of error
====================================================================================================================
----------------------------points to be remembered in Exception handling---------------------------
======================================================================================================================
1) When the Application Users enters Invalid Input then we get RunTime Errors.
2) By default RunTime Errors generates Technical errors messages and they are understandable by Programmers but not
   by end users.
3) Definition of Exception: Every RunTimr Error is called Exception
(Invalid INput--> RunTime Error--> Exception. Hence Every Invalid input gives exception)
4) Every Exception by default generates Technical Error Messages, they are understanble by Programmers but not ende users.
   Hence Industry recommends, Convert technical error messages into user-friendly error messages by using
   "exception handling" concept.
5) Definition of Exception-Handling:
   ==> The process of Converting Technical Error Messages to user-friendly error messages
6)When an exception occurs internally 3 steps takes place. They are:
  a) Program execution terminated abnormally
  b) PVM comes out pf Program flow without executing rest of the statements
  c) By default, PVM generates Technical Error Messages.
7) To do a,b and c steps, PVM create an object of appropriate execution class.
8) When an exception occurs then PVM create an object of appropriate exception class, Program exeception terminated abnormally
   PVM comes out of program flow without executing rest of the statements and by default, PVM generates Technical
   Error Messages.
9) Hence in Python all execution are considered as objects and behind of objects there exception class names.
10) There, Normal classes provides Successful execution of program and exception classes provides Abnormal Termination.
   """

# ==================================== EXAMPLES ======================================
a="100abc"
z=int(a)
print("value of z={}".format(z))  # Gives ValueError, it is a invalid error

a="100"
z=int(a,"abc")
print("value of z={}".format(z))  # Gives TypeError(this is hungarian notation)

