#This program reads specified number of chars from file ------ read(no. of chars)
with open("hyd.data","r") as fp:
    print("Intial Index/Pos of fp={}".format(fp.tell())) #0
    fdata=fp.read(3)
    print("FIleData=",fdata)
    print("Now Index/Pos of fp={}".format(fp.tell()))
    fdata = fp.read()
    print("FIleData=", fdata)
    print("Now Index/Pos of fp={}".format(fp.tell()))
    fp.seek(0)
    fdata = fp.read(5)
    print("FIleData=", fdata)
    print("Now Index/Pos of fp={}".format(fp.tell()))
