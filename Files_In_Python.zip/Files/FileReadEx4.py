#This program reads all the lines from file ------ readlines()
with open("hyd.data","r") as fp:
    filelines=fp.readlines()         # 1 way of getting output
    print(filelines)

print("="*50)
with open("hyd.data","r") as fp:
    filelines=fp.readlines()         # 2 way of getting output, getting space after the line
    for line in filelines:
        print(line)

print("="*50)
with open("hyd.data","r") as fp:
    filelines=fp.readlines()         # 2 way of getting output, not getting space after the line
    for line in filelines:
        print(line,end="")

print("="*50)
filename = input("Enter the FIleName:")
try:
    with open(filename,"r") as fp:
        filelines=fp.readlines()         # 2 way of getting output, not getting space after the line
        for line in filelines:
            print(line,end="")
except FileNotFoundError:
    print("File Does Not Exists")