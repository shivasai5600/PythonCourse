""" ================================== Files Opening Modes ===================================================
==>To perform read and write operations on files, we use file opening modes.
==>In Python, we have 7 file opening modes.They are:

1)r 2)w 3)a 4)r+ 5)w+ 6)a+ 7)x
-----------------------------------------------------------------------------------------
1)r :
-->This mode is used for opening the file in read mode and we can perform read mode.
-->it is one of default file opening mode
-----------------------------------------------------------------------------------------
2)w:
-->This mode is used for opening the file always in write mode newly irrespective of new or existinf file
-->If the file already exist then existing data of the file overlapped with new data.
-----------------------------------------------------------------------------------------
3)a:
-->This mode is used for appending the data(Writing the data)
-->If we open the new file in 'a' mode then new data written to the file from the begining.
-->If we open the existing file in 'a' mode then new data added at the end of existing data(called Appending)
---------------------------------------------------------------------------------------------
4)r+:
-->This mode is used for opening the File Read Mode
-->When we open the file r+ mode then first we must perform read operation and later we can perform write operation
----------------------------------------------------------------------------------------------
5)w+:
-->This mode is used for opening the File always in write mode newly irrespective of new or existinf file
-->If the file already exist then existing data of the file overlapped with new data.
-->With this mode additionally,we can perform read operation after performing write Operations
-------------------------------------------------------------------------------------------------
6)a+:
-->This mode is used for appending the data(Writing the data)
-->If we open the new file in 'a+' mode then new data written to the file from the begining.
-->If we open the existing file in 'a+' mode then new data added at the end of existing data(called Appending)
-->With this mode additionally, we can perform read operation after performing write Operations.
----------------------------------------------------------------------------------------------------
7)x:
-->This mode is used for Opening any new File in Write Mode Exclusively.
-->If the file already exists and if we open such File in 'x' mode then we get 'FileExistError'.



"""