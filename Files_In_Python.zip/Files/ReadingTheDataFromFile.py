""" ============================ Reading The Data From The File =============================================
==>To Read the data from the file,we have 4 pre-defied functions,They are:
   a)read()
   b)read(no.of chars)
   c)readline()
   d)readlines()
------------------------------------------------------------------------------------
a)read():
------------
->This Function is used for reading entire content of file data in the form of str.
-> Syntax :       varname=filepointer.read()

Example:

with open("hyd.data") as fp:
    filedata=fp.read()
    print("="*50)
    print("Content of FIle")
    print("="*50)
    print(filedata)
    print("="*50)
try:
    with open("hyd1.data") as fp:
        filedata=fp.read()
        print("=" * 50)
        print("Content of FIle")
except FileNotFoundError:
    print("File Doesn't Exists")
----------------------------------------------------------------------------------------------------------
b)read(no.of chars):
-----------------------
->THis is used for reading specified number of characters from the given file
-> Syntax :    varname=filepointer.read(no. of chars)

Examples :

#This program reads specified number of chars from file ------ read(no. of chars)
with open("hyd.data","r") as fp:
    print("Intial Index/Pos of fp={}".format(fp.tell())) #0
    fdata=fp.read(3)
    print("FIleData=",fdata)
    print("Now Index/Pos of fp={}".format(fp.tell()))
    fdata = fp.read()
    print("FIleData=", fdata)
    print("Now Index/Pos of fp={}".format(fp.tell()))
    fp.seek(0)
    fdata = fp.read(5)
    print("FIleData=", fdata)
    print("Now Index/Pos of fp={}".format(fp.tell()))
-------------------------------------------------------------------------------------------------------------
c)readline()
-------------
->This function is used for reading one line at a time from file
-> Syntax :          varname= filepointer.readline()

Examples:

#This program reads specified number of chars from file ------ readline
with open("hyd.data","r") as fp:
    line=fp.readline()
    print(line)
    line = fp.readline()
    print(line)
    line = fp.readline()
    print(line)

---------------------------------------------------------------------------------------------------------------
d)readlines()
---------------
->This function is used for reading all the lines from file in the form of list
-> Syntax :  listobj = filepointer.readlines()

Examples:

#This program reads all the lines from file ------ readlines()
with open("hyd.data","r") as fp:
    filelines=fp.readlines()         # 1 way of getting output
    print(filelines)

print("="*50)
with open("hyd.data","r") as fp:
    filelines=fp.readlines()         # 2 way of getting output, getting space after the line
    for line in filelines:
        print(line)

print("="*50)
with open("hyd.data","r") as fp:
    filelines=fp.readlines()         # 2 way of getting output, not getting space after the line
    for line in filelines:
        print(line,end="")

print("="*50)
filename = input("Enter the FIleName:")
try:
    with open(filename,"r") as fp:
        filelines=fp.readlines()         # 2 way of getting output, not getting space after the line
        for line in filelines:
            print(line,end="")
except FileNotFoundError:
    print("File Does Not Exists")
"""