# Example---1
try:
    wp=open("stud.info","x")
    print("File Opened in Read Mode")
    print("="*50)
    print("FIle Opened in Read Mode Successfully")
    print("=" * 50)
    print("type of wp=",type(wp))
    print("="*50)
    print("File Name",wp.name) #Gives Name Of File
    print("Mode Name",wp.mode) #Gives Mode Name
    print("Is stud.info is readable?=",wp.readable())
    print("Is stud.info is Writable?=",wp.writable())
    print("Is stud.info is closed?=",wp.closed)
    print("="*50)
except FileExistsError:
    print("File Already Exists")

# =============== Example -------2 ==================
try:
    wp=open("st.data","x")
    print("File is Opened in Exclusively Write Mode")   #if u run this program multiple times it gives an Exception,File Already Exsits
    print("="*50)
    print("type of wp=",type(wp))
    print("="*50)
    print("File Name",wp.name) #Gives Name Of File
    print("Mode Name",wp.mode) #Gives Mode Name
    print("Is stud.info is readable?=",wp.readable())
    print("Is stud.info is Writable?=",wp.writable())
    print("Is stud.info is closed?=",wp.closed)
    print("="*50)
except FileExistsError:
    print("File Already Exists")