""" ============================== Number of Approaches to Open the Files ======================================
 ==> TO open the file for performing operations, we have 2 syntaxs.They are:
     1)By using open()
     2)By using 'with open() as'

--------------------
1)By using open()
--------------------
Syntax:       varname=open("FileName","FileMode")

Explanation:
-->'varname' is an object of type <class,'_TextIoWrapper'> and it acts as File Pointer.
-->open() is a Pre-Defined Function used for opening the specified file name in specified file mode.
-->File Name represents Name of the File
-->File Modes can be either r,w,a,r+,w+,a+,x
-->When we open the file with this approach,we must close the file explicitly by using close()(Manual Closing Files)
   THis approach is unable to provide auto-closing the files (or) auto-closable files.

===================================================================================================================
--------------------------------
2)By using "with open() as"
-------------------------------
Syntax:        with  open=("File Name","File Mode") as varname:
                    -------------------------------
                    ----Block Of Statemnets--------
                    -----Operation of Files--------
               -----------------------------------------------
               Other statements in Programs
               ---------------------------------------------
---------------
Explanation:
--------------
-->'with' and 'as' are the keywords
-->Open is a Pre-Defined Function used to open the file in specified file mode.
-->File Name represents Name of the File
-->File Modes can be either r,w,a,r+,w+,a+,x
-->'varname' represents an object of type <class,'_TextIoWrapper'> and it acts as File Pointer.
"""