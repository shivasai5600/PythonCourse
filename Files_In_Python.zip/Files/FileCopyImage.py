#this program copy an image by using files
with open("imaaage.png","rb") as fp:
    filedata=fp.read()
    with open("Copyimaage.png","wb") as wp:
        wp.write(filedata)
        print("Image Copied -- verify")