#This Program reads the data from the file and display on the console
with open("hyd.data") as fp:
    filedata=fp.read()
    print("="*50)
    print("Content of FIle")
    print("="*50)
    print(filedata)
    print("="*50)
try:
    with open("hyd1.data") as fp:
        filedata=fp.read()
        print("=" * 50)
        print("Content of FIle")
except FileNotFoundError:
    print("File Doesn't Exists")
# --------------------------------------------------------------------------------------------------------------
# write a pyhton program which will read the content from the file and display on the monitor
try:
    filename=input("Enter the File Name:")
    with open(filename) as fp:
        filedata=fp.read()
        print("=" * 50)
        print("Content of FIle")
        print("=" * 50)
        print(filedata)
        print("=" * 50)
except FileNotFoundError:
    print("File Doesn't Exists")