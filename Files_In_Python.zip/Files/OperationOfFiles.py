""" ============================= Operations Of Files ===================================================
==>On Files, we can perform 2 types of Operations: They are:
   1.Read Operation
   2.Write Operation
--------------------
1.Write Operation
-------------------
=>The purpose of write operation is that "To transfer Temporary data from Main Memory into file of secondary memory".
---------
=>Steps
---------
    1.Choose the File Name
    2.Open the File Name in write Mode
    3.Perform Cycle of Write Operations
=>While we are Performing Write Operations, we get some exceptions.They are:
  a)FileExistError
  b)IOError
---------------------------------------------------------------------------------------------------------------------
-------------------
2.Read Operation
-------------------
=>The purpose of Read operation is that "To Read data from file of secondary memory into object of main memory".
---------
=>Steps
---------
    1.Choose the File Name
    2.Open the File Name in Read Mode
    3.Perform Cycle of Write Operations
=>While we are Performing Read Operations, we get some exceptions.They are:
  a)FileNotFoundError
  b)EOFError
   """