""" ========================= Files In Python ============================================================
------------------------------------Index:--------------------------------------------
==>Purpose of Files
==>Types of Applications in the context of files
   a)Non-Persistent Applications
   b)Persistent Applications
==>Definition of Files
==>Types of Files
   a)Text Files
   b)Binary Files
==>Operation of Files
   a)Read Operation
   b)Write Operation
==>File Opening Modes
   1) r  2) w  3) a  4) r+  5) w+  6) a+  7) x
==>Number of Approaches to open the File
   a)By using open()
   b)By using " with open() as"
==>Functions required For Reading the Data from Files
   a)read()
   b)read(no. of chars)
   c)readline()
   d)readliness()
==>Random Access Files
   a)tell()
   b)seek()
==>Functions Required For writing the Data to the Files
   a)write()
   b)writeliness()
==>Programming Examples
-----------------------------------------------------------------------------------------------
==>Pickling (Object Serialization) and Un-Pickling (Object De-Serialization)
==>Module Name of Pickling and Un-Pickling
==>Programming Examples

--------------------------------------------XXXX-------------------------------------------------------------------------
============================== Types Of Files in Python =========================================
==>The main Purpose of Files is that "To Achieve the Data Persistency"
==>In the context of files,we have two types of Applications.They are:
   a)Non-Persistent Application
   b)Persistent Application
==>In Non-Persistent Applications Development,We accept the data from Key Board,Stored in main memory(temporary data),
   processed and results are displayed and shown on the monitor.
==>We know that main memory is Temporary Memory and whose datat is volatile.
==>Since Data is an important for organisation for making effective decisions,so that data must stored permanently
==>In Persistent Applications Development,We accept the data from Key Board,Stored in main memory(temporary data),
   processed and whose results must stored permanently.
==>In Industry we have two approaches to store the data permanently. They are:
   a)By using Files
   b)By using Data Base Software(Oracle,MySQL...etc)
"""