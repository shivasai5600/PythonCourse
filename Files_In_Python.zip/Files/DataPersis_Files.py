""" ============================== Data Persistency of Files in Python =====================================
--------------
Def of File:
--------------
==>A FIle is a Collection of Records
==>Files Resides in Secondary Memory
==>Technically, File Name is a named location in secondary memory
--------------------------------------------------------------------
==>All the objects data of main memory becomes records in FIle of Secondary Memory and Vice-Versa
------------------
Def. of stream
-----------------
==>The Flow of Data between Main Memory and File of Secondary memory is called Stream."""