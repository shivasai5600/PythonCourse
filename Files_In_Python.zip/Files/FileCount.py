# THis Program counts number of lines,words,and chars in a file
filename=input("ENter your File Name:")
try:
    with open(filename,"r") as fp:
        print("="*50)
        print("Content of File")
        print("="*50)
        for kvr in fp:
            print(kvr,end="")
        else:
            print("="*50)
            nl=0
            nw=0
            nc=0
            fp.seek(0)
            lines=fp.readlines()
            for line in lines:
                nl=nl+1
                nw=nw+len(line.split())
                nc=nc+len(line)
            else:
                print("="*50)
                print("Number of Lines=",nl)
                print("Number of Words=",nw)
                print("Number of Chars=",nc)
                print("="*50)
except FileNotFoundError:
    print("File Does Not Exists")