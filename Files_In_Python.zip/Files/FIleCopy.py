# Program for Copying the Content of one file to another file

sfile=input("Enter the FIle Name:")
try:
    with open(sfile) as rp:
        dfile=input("Enter the File Name:")
        with open(dfile,"a") as wp:
            sfiledata=rp.read()
            wp.write(sfiledata)
            print("\n'{}' file data copied into '{}' file".format(sfile,dfile))
except FileNotFoundError:
    print("File Does Not Exists")