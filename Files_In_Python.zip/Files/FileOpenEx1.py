try:
    fp=open("stud.info","r")
    print("="*50)
    print("FIle Opened in Read Mode Successfully")
    print("=" * 50)
    print("type of fp=",type(fp))
    print("="*50)
    print("File Name",fp.name) #Gives Name Of File
    print("Mode Name",fp.mode) #Gives Mode Name
    print("Is stud.info is readable?=",fp.readable())
    print("Is stud.info is Writable?=",fp.writable())
    print("Is stud.info is closed?=",fp.closed)
    print("="*50)
except FileNotFoundError:
    print("File Does Not Exist")
finally:
    print("Iam from finally block")
    print("Is stud.info is closed?=",fp.closed)