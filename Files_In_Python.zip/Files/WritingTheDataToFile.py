""" =============================== Writing the Data To File ==================================================
     a) write()
     b)writelines()
------------------------
a)write()
--------------------
->This Function is used for writing any type of data to the file in the form of str.

-> Syntax:      filepointer.write(strdata)

->Example: FileWriteEx1.py
-------------------------------------------------------------------------------------------------------
b)writelines()
-------------------
->THis function is used for writing any iterable object data to the file in the form of str only

-> Syntax:    filepointer.writelines(iterable object)

->Example: FileWriteEx2.py
"""