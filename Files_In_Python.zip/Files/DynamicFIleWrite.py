# Program reading the data form KBD and write that data to the file
import sys
with open("hyd.data","a") as fp:
    print("Enter the Lines of Text and press 'quit' to stop")
    while(True):
        kbddata=input()
        if(kbddata=="quit"):
            sys.exit()
        else:
            fp.write(kbddata+"\n")
    print("\nData written to the File -- verify")