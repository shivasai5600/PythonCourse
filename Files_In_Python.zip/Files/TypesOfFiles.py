""" ============================== Types Of Files ========================================
==>In Python Programming,we have two types of Files. They are:
    a)Text Files
    b)Binary Files

---------------
a)Text Files:
----------------
->Text Files contains Alphabets,Digits,Special Symbols Only
->Text Files are denoted by a 't'
->By default a Text File is taken as Text File
Example: .doc, .py, .cpp, .xlxs, .txt,........etc

-------------------
b)Binary Files:
------------------
->A Binary Files contains the data in the form of Binary Format and it mavhine readable.
->Binary File is denoted by letter 'b'
->Examples:   Images(.png, .gif, .jpeg, .jpg,...etc)
              audio files
              video files(MP3...etc)
              PDF files

"""