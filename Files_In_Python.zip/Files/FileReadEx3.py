#This program reads specified number of chars from file ------ readline()
with open("hyd.data","r") as fp:
    line=fp.readline()
    print(line)
    line = fp.readline()
    print(line)
    line = fp.readline()
    print(line)

