#This program write address of different people in addr.info file--write()
with open("addr.info","w") as wp:
    #write the address of Rossum
    wp.write("Rossum\n")
    wp.write("Python\n")
    wp.write("Netherlands\n")
    print("\nAddress written to the file successfully--verify")
print("Type of addr.info",type(wp))

with open("addr.info","a") as wp:
    #write the address of Rossum
    wp.write("GUido\n")
    wp.write("Java\n")
    wp.write("GreenLands\n")
    print("\nAddress written to the file successfully--verify")