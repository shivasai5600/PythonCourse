#This program write iterable objects to the file --writelines()
tpl=[10,"sai",63.33,"Java"]
with open("stud.aadr","a") as fp:
    fp.writelines(str(tpl)+"\n")
    print("\nIterable object data written to the file")