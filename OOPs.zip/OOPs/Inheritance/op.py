class Operation:
    def addop(a,b):
        print("sum of {},{}={}".format(a,b,a+b))