#This program demonstates the concept of inheritance

class Company:
    def setcomdet(self):
        self.cname=input("Enter the Company Name: ")
        self.cplace=input("Enter the Company place: ")
    def discomdet(self):
        print("Company Name: {}".format(self.cname))
        print("Company Place: {}".format(self.cplace))

class Employee(Company):
    def getempdet(self):
        self.eno=int(input("Enter EMployee No: "))
        self.ename=str(input("Enter the EMployee Name: "))
    def disempdet(self):
        print("Employee No: {}".format(self.eno))
        print("Employee Name: {}".format(self.ename))

e=Employee()
e.getempdet()
e.setcomdet()
e.disempdet()