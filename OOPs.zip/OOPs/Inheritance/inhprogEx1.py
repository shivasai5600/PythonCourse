class Operation:
    def addop(self,a,b):
        print("sum of {},{}={}".format(a,b,a+b))


class Ravi(Operation):pass
class Raju(Operation):pass
class Ram(Operation):pass

r=Ravi()
r.addop(3,4)
m=Raju()
m.addop(5,6)
s=Ram()
s.addop(10,8)