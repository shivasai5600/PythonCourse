import gc,time

class Employee:
    def __init__(self):
        print("Im from Constructor")
        self.eno=10
        self.name="ss"
        print("{}\t{}".format(self.eno,self.name))
    def __del__(self):
        print("GC calls destructor for de-allocating unused memory space")

print("Is Garbage Collector running=",gc.isenabled()) #True
eo=Employee()
gc.disable()
print("Is Garbage Collector running=",gc.isenabled())  #False
time.sleep(5)
gc.enable()
print("Is Garbage Collector running=",gc.isenabled())
time.sleep(5)
