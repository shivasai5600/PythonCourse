import gc


class Employee:
    def __init__(self):
        print("Im from Constructor")
        self.eno=10
        self.name="ss"
        print("{}\t{}".format(self.eno,self.name))
    def __del__(self):
        print("GC calls destructor for de-allocating unused memory space")

print("Is Garbage Collector running=",gc.isenabled()) #True
eo=Employee()
