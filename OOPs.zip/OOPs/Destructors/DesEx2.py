class Employee:
    def __init__(self):
        self.eno=10
        self.name="ss"
        print("{}\t{}".format(self.eno,self.name))
    def __del__(self):
        print("GC calls destructor for de-allocating unused memory space")

eo=Employee()
del eo              #GC calls __del__(self)
eo2=Employee()
del eo2             #GC calls __del__(self)
eo3=Employee()