class Student:
    def setstudvalues(self,sno,sname,smarks,cname="JNTUH"):
        self.stno=sno
        self.sname=sname
        self.smarks=smarks
        self.cname=cname

    def dispstudata(self):
        print("\t{}\t{}\t{}\t{}".format(self.stno,self.sname,self.smarks,self.cname))
