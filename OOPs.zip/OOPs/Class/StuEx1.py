# This Program cresate class, classname, sno,name,marks by using classes and objects

print("Before writing the class")

class Student(): pass

print("After writing the class")

# output: will be the print(), class() will pass

#main program
s1 = Student() #object creation
print("content of s1 before adding data=", s1.__dict__) #output : {}, empty dictionary
s1.sno=10
s1.name="ps"
s1.marks=11

print("content of s1 after adding data=", s1.__dict__)