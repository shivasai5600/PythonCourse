class Table:
    def getnumber(self):
        self.n=int(input("Enter the Number: "))

    def gettable(self):
        self.getnumber()
        if (self.n<=0):
            print("{} is invalid input".format(self.n))
        else:
            print("="*40)
            print("Mul Table of {}".format(self.n))
            print("=" * 40)
            for i in range(1,11):
                print("\t{} * {}={}".format(self.n,i,self.n*i))
            print("=" * 40)