from moduletable import Table

t=Table()
print(t.__dict__)

t.gettable()