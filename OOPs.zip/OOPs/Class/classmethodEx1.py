""" THis program demonstrates the concept of Class Level Method"""
class Employee:

    @classmethod
    def getcompaddr(cls):
        cls.cname="MPH"
        cls.addr="BLR"

    def getempdata(self):
        print("="*50)
        self.eno=int(input("ENter the number: "))
        self.ename=str(input("Enter the Name: "))

    def disempdata(self):
        print("="*50)
        print("EMployee Number {}".format(self.eno))
        print("Employee Name {}".format(self.ename))
        print("EMployee Company Name {}".format(Employee.cname))
        print("Enter Company Address {}".format(Employee.addr))
        print("=" * 50)

#main program
Employee.getcompaddr()

e1=Employee()
e2=Employee()
print("Enter the First Employee Details")
e1.getempdata()
print("="*50)
print("Enter the Second Employee Details")
e2.getempdata()

print("Display the First EMplyee Details: ")
e1.disempdata()
print("Display the Second EMplyee Details: ")
e2.disempdata()
