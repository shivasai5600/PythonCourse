# this program reads all the recorrds of employee table by using classes and objects

import mysql.connector

class SakilaRecords:
    def getrecords(self):
        con=mysql.connect(host="localhost",
                                    user="user",
                                    password="root",
                                    database="sakila")
        cur=con.cursor()
        cur.execute("select * from actor")
        print("="*50)
        for colname in [colnames[0] for colnames in cur.description]:
            print("{}".format(colname),end=" ")
        print()
        print("="*50)
        #get records
        records = cur.fetchall()
        for record in records:
            for rec in record:
                print("{}".format(rec),end=" ")
            print()
        print("="*50)

t=SakilaRecords()
t.getrecords()