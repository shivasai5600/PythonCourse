import pickle,sys
from studentPickling import Student

class StudentPick:
    def insertstudata(self):
        with open("stu.data","ab") as fp:
            while(True):
                try:
                    print("="*50)
                    self.sno=int(input("Enter the Student NUmber: "))
                    self.sname=input("Enter the Student Name: ")
                    self.smarks=float(input("Enter Studennt Marks: "))
                    # create student class object
                    so=Student()
                    so.setstudvalues(self.sno,self.sname,self.smarks)
                    #dump or save student data in file
                    pickle.dump(so,fp)
                    print("="*50)
                    print("\nStudent Record Inserted Successfully")
                    print("="*50)
                    ch=input("Do u want to insert another record(yes/no)")
                    if(ch.lower()=="no"):
                        print("Thanks for using this program")
                        sys.exit()
                except ValueError:
                    print("Don't enter strs/alpha-numericals")

#main program
sp=StudentPick()
sp.insertstudata()


