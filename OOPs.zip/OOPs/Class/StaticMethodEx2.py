#This program demonstarates the concept of claculator Mthod
import sys


class Cal:
    @staticmethod
    def calculate(obj):
        match(obj.op):
            case "+":
                print("sum of {},{}={}".format(obj.a,obj.b,obj.a+obj.b))
            case "-":
                print("sub of {},{}={}".format(obj.a, obj.b, obj.a-obj.b))
            case "*":
                print("mul of {},{}={}".format(obj.a, obj.b, obj.a*obj.b))
            case "/":
                print("div of {},{}={}".format(obj.a, obj.b, obj.a/obj.b))
            case "//":
                print("floordiv of {},{}={}".format(obj.a, obj.b, obj.a//obj.b))
            case "**":
                print("exp of {},{}={}".format(obj.a, obj.b, obj.a**obj.b))
            case "%":
                print("mod of {},{}={}".format(obj.a, obj.b, obj.a%obj.b))
            case "_":
                print("{} is not of Arithmatic operation".format(obj.op))

class Numbers:
    def getvalues(self):
        try:
            self.a=float(input("Enter First Value: "))
            self.b=float(input("Enter Second Value: "))
            self.op=input("Enter any Arithmatic operator: ")
        except ValueError:
            print("Don't str/special symblos/alpha-numericals")
            sys.exit()
#main program
n=Numbers()
n.getvalues()

Cal.calculate(n)
