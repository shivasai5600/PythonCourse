# This Program cresate class, classname, sno,name,marks by using classes and objects

class Student():
    course = "Python"   # classlevelmember
    room = "ttt"

#main program
s1=Student() #object creation
s2=Student() #object creation

#add data to s1
s1.sno = 10       #instancelevelmember
s1.name = "ss"    #instancelevelmember
s1.marks = 11     #instancelevelmember

s2.sno = 20
s2.name = "ps"
s2.marks = 21

#disppay object of s1
print("="*50)
print("s1 object contet")
print("="*50)
print("Student No. : ",s1.sno)
print("Student Name. : ",s1.name)
print("Student Marks. : ",s1.marks)
print("Student Course :",Student.course)
print("Student Room : ",s1.room)
print("="*50)
print("s2 object contet")
print("="*50)
print("Student No.   : ",s2.sno)
print("Student Name  : ",s2.name)
print("Student Marks : ",s2.marks)
print("Student Course :",Student.course)
print("Student Room : ",s1.room)