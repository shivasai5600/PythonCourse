""" This is Example of as StuEx1 with using functions to reduce the code reusability"""

class Student:
    def readstudet(self):
        print("="*50)
        self.sno=int(input("Enter the Student Number: "))
        self.name=str(input("Enter the Student Name: "))
        print("=" * 50)
    def disstudet(self):
        print("=" * 50)
        print(f"Student Number={self.sno}")
        print(f"Student Name={self.name}")
        print("=" * 50)


"""main program"""

s1=Student()
s2=Student()
print("Enter the First Student Details")
s1.readstudet()
print("Enter the Second Student Details")
s2.readstudet()
print("\nFirst Student Information: ")
s1.disstudet()
print("\nSecond Student Information: ")
s2.disstudet()

"""======================================== XXXXX ======================================
ANother way of writing calling instanceMethod from Instance Method"""
class Student1:

    def readstudet1(self):
        print("="*50)
        self.sno=int(input("Enter the Student Number: "))
        self.name=str(input("Enter the Student Name: "))
        print("=" * 50)
        self.disstudet1()

    def disstudet1(self):
        print("=" * 50)
        print(f"Student Number={self.sno}")
        print(f"Student Name={self.name}")
        print("=" * 50)


"""main program"""

s1=Student1()
s2=Student1()
print("Enter the First Student Details")
s1.readstudet1()
print("Enter the Second Student Details")
s2.readstudet1()

