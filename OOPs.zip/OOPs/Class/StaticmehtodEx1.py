#THis program demonstarates the concept of Statitic method

class Human:
    @staticmethod
    def dispdata(obj):
        print("="*50)
        for k,v in obj.__dict__.items():
            print("\t{}\t{}".format(k,v))
        print("="*40)

#main program
emp=Human()
stu=Human()
tea=Human()

#add data to the emp object
emp.eno=10
emp.name="ss"
#add data to the stu object
stu.eno=11
stu.name="gs"
#add data to the tea object
tea.eno=32
tea.name="fs"

#dispaly the output of the objects
Human.dispdata(emp)
Human.dispdata(stu)
Human.dispdata(tea)



