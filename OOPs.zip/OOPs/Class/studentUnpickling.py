import pickle


class StudentUnpick:
    def getstudentrecords(self):
        try:
            with open("stu.data","rb") as fp:
                print("-"*50)
                print("\tStno\tSname\tSmarks\tScanme")
                print("-"*50)
                while(True):
                    try:
                        obj=pickle.load(fp) #type of obj=<class "studentPickling.Student">
                        obj.dispstudata()
                    except EOFError:
                        print("-"*50)
                        break
        except FileNotFoundError:
            print("FileDoesNot Exists")

up=StudentUnpick()
up.getstudentrecords()


