from ConsEncapEx import Account

so=Account()
# print(so.sno)    # "Account" object has no attribute 'sno'
so.cud()