class Account:
    def setaccountdet(self):
        self.__acno=1234         #keeping data member private, to not visible the data for other programs(__acno)
        self.cname="ss"
        self.__bal=34.45
        self.bname="SBI"
        self.__pin=3456