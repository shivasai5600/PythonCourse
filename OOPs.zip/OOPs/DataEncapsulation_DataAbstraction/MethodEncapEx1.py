class Account:
    def __setaccountdet(self):
        self.acno=1234         #keeping data member private, to not visible the data for other programs(__acno)
        self.cname="ss"
        self.bal=34.45
        self.bname="SBI"
        self.pin=3456

    def scds(self):
        print("im a customer in bank")