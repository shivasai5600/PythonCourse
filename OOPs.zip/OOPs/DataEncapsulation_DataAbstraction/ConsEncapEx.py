class Account:
    def ____init__(self): #Constructor level Encapsulation
        self.sno=10
        self.name="ss"
    def cud(self):
        print("Im a constructor class")