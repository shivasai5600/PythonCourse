from MethodEncapEx1 import Account

so=Account()
so.__setaccountdet()
# print("DIsplay the Account Number=",so.acno) #not possible to access,bcz acno is encapsulated
# print("DIsplay the Account Name=",so.cname)
# print("DIsplay the Account Bal=",so.bal)     #not possible to access,bcz acno is encapsulated
# print("DIsplay the Account Branch Name=",so.bname)
# print("DIsplay the Account Pin=",so.pin)     #not possible to access,bcz acno is encapsulated

so.scds()