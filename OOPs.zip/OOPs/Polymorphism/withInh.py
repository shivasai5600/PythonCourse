class C1:
    def x(self):
        print("C1-x()")

class C2(C1):
    def y(self):
        print("C1-y()")

class C3(C1):
    def z(self):
        print("C1-z()")

class C4(C2,C3):
    def k(self):
        print("C1-k()")
        

o4=C4()
o4.x()
o4.y()