class C1:
    def x(self):
        print("C1-x()")


class C2(C1):
    def x(self):
        print("C1-y()")


class C3(C1):
    def x(self):
        print("C1-z()")


class C4(C2, C3):
    def x(self):
        print("C1-k()")
        super().x()
        super().x()
        super().x()
        C2.x(self)
        C3.x(self)
        C1.x(self)


o4 = C4()
o4.x()
