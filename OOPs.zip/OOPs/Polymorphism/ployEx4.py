#THis Example is for constructor overridding

class Test:
    def __init__(self):
        print("Test is Constructor")

class Sample(Test):
    pass

s=Sample()

print("="*60)

class Tt:
    def __init__(self):
        print("Test is Constructor")

class Sample1(Tt):
    def __init__(self):
        print("Sample is Constructor")
        super().__init__()
s=Sample1()