#This Program calculates area of Different Figures such as Circle and Square

class Circle:
    def area(self):
        self.r=float(input("Enter the Radius: "))
        self.ac=3.14*self.r**2
        print("Area of Circle={}".format(self.ac))

class Square:
    def area(self):
        self.s=float(input("Enter the Side: "))
        self.sa=self.s**2
        print("Area of Side={}".format(self.sa))

class Rect(Circle,Square):pass


a=Rect()
a.area()