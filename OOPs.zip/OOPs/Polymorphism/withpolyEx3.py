class India:
    def countrytype(self):
        print("India is developing Country")
    def lang(self):
        print("Indians can speak multiple languages")

class USA:
    def countrytype(self):
        print("USA is developed Country")
    def lang(self):
        print("USA can speak one language")

class ShoeIn:
    @staticmethod
    def dis(ob):  # static method
        ob.countrytype()
        ob.lang()

obj = India()
fgh = USA()

ShoeIn.dis(obj)  # Output from India class
ShoeIn.dis(fgh)  # Output from USA class
