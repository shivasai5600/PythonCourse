class India:
    def countrytype(self):
        print("India is developing Country")
    def lang(self):
        print("Indians can speak multiple languages")

class USA:
    def countrytype(self):
        print("USA is developed Country")
    def lang(self):
        print("USA can speak one languages")

obj=India()
fgh=USA()

for bv in (obj,fgh):
    bv.countrytype()   #object level method
    bv.lang()