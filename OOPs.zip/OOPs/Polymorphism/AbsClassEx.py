class Banking:                   #Here banking class is called Abstract class
    def openac(self): pass       #Null Body Methods
    def deposit(self,amt): pass
    def loan(self,name,lamt): pass

class Ravi(Banking):
    def openac(self):
        print("Ravi opened account in SBI")
class Person(Banking):
    def loan(self,name,lamt):
        print("{} Taken {} as loan and went out of India".format(name,lamt))

r=Ravi()
r.openac()
print("="*40)
r.deposit(100)
p=Person()
p.loan("Mallya",6.3)