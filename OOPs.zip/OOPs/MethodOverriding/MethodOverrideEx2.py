class Dog:
    def xnoise(self):  # Original Method
        print("Makes noise of BOW BOW")


class Cat(Dog):
    def xnoise(self):  # Overridden Method
        print("Makes noise of MEOW MEOW")
        # super().xnoise()  # Here u can write Dog.xnoise() also


class Cow(Cat):
    def xnoise(self):  # overridden Method
        print("Makes noise of Amba Amba")
        Cat.xnoise(self)
        Dog.xnoise(self)


c = Cow()
c.xnoise()

print("="*60)
class Circle:
    def draw(self):
        print("Drawing circle: ")

class Rect(Circle):
    def draw(self):               #overridden Method
        print("Drawing Rectangle.")
        # super().draw()
        # Circle.draw(self)
r=Rect()
r.draw()