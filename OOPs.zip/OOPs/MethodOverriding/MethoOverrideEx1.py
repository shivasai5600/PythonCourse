class Dog:
    def noise(self):       #Original Method
        print("Makes noise of BOW BOW")

class Cat(Dog):
    def noise(self):       #Overriden Method
        print("Makes noise of MEOW MEOW")

c=Cat()
c.noise()

print("="*50)
class D:
    def dnoise(self):       #Original Method
        print("Makes noise of BOW BOW")

class C(D):
    def cnoise(self):       #Overridden Method
        print("Makes noise of MEOW MEOW")

c=C()
c.cnoise()
c.dnoise()

print("="*50)
class D1:
    def xnoise(self):       #Original Method
        print("Makes noise of BOW BOW")

class C1(D1):
    def xnoise(self):       #Overridden Method
        print("Makes noise of MEOW MEOW")
        super().xnoise()                          # Here u can write Dog.xnoise() also

c=C1()
c.xnoise()

print("="*50)
class D2:
    def xnoise(self):       #Original Method
        print("Makes noise of BOW BOW")

class C2(D2):
    def xnoise(self):       #Overridden Method
        print("Makes noise of MEOW MEOW")
        super().xnoise()                          # Here u can write Dog.xnoise() also
        
class V2(C2):
    def xnoise(self):      #overridden Method
        print("Makes noise of Amba Amba")
        super().xnoise()

c=V2()
c.xnoise()
