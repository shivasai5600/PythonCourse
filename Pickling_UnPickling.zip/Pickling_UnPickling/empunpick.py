#this program reads employee records from file by using un-pickling
import pickle
try:
    with open("emp.data","rb") as fp:
        print("-"*20)
        print("Employee Records")
        print("-" * 20)
        while(True):
            try:
                obj=pickle.load(fp)
                for val in obj:
                    print("{}".format(val),end=" ")
                print()
            except EOFError:
                print("-" * 20)
                break
        # print(type(obj))      #<type, 'list'>
except FileNotFoundError:
    print("\nSource File DOes Not Exsits")