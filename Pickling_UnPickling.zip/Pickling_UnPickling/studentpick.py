#This Program for accepting student no,name,marks and college name and save them in the file by using pickling

import pickle                               # Program ----(A)
with open("stud.data","ab") as sp:
    while(True):
        print("-"*50)
        #accepting student details
        sno=int(input("Enter the Student Number:"))
        sname=str(input("Enter the Student Name:"))
        marks = float(input("Enter the Student Marks:"))
        uname = input("Enter the Student UName:")
        #create an empty list
        l=list()
        #append student values in l
        l.append(sno)
        l.append(sname)
        l.append(marks)
        l.append(uname)
        #save object l in a file
        pickle.dump(l,sp)
        print("-"*50)
        print("Student Record Saved In a File")
        print("-"*50)
        ch=input("Do u want to insert another Record(yes or no):") #hyd,NO
        if(ch.upper()=="NO"):
            print("Thanks for Using this Program")
            break
        if (ch.lower()!="yes"):
            print("Thanks for Using this Program")
            break