#Accept employee details and save the file by using pickling
import pickle
noe=int(input("Enter how many employee datails data u have:"))
if(noe<=0):
    print(f"{noe} is Invalid number of Employees:")
else:
    #open the file write mode
    with open("emp.data","ab") as fp:
        for i in range(1,noe+1):
            print("="*50)
            print(f"\nEnter {i} Employee Details")
            print("=" * 50)
            #Accept employee details
            eno=int(input("\tEnter Employee Number:"))
            ename=input("\tEnter Employee Name:")
            sal=float(input("\tEnter Employee Salary:"))
            #create an empty list
            lst=list()
            lst.append(eno)
            lst.append(ename)
            lst.append(sal)
            #dump the lst data into file
            pickle.dump(lst,fp)
            print("=" * 50)
            print("\n{} Employee Record saved Successfully in file".format(i))
