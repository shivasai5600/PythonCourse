""" ================================= Pickling and Un-Pickling ===============================================
============================================== OR ============================================================
============================ Object Serialization and Object De-Serialization =================================
----------------
 Pickling :
---------------
==>Let us assume there exist an object which contains multiple values.To save or write data to main memory into
   the file of secondary memory by using write() and writelines(), they transfers and values in the form of value
   by value and it is one of the time consuming process(multiple write operations).
   TO overcome this time consuming process, we must use the concept of Pickling.
==>The Advantage of Pickling concept is that with single write operation , we can save or write entire object
   data of main memory into the file of secondary memory
----------------------
Definition of Pickling:
----------------------
==>The Process of saving or transfering entire object content of main memory onto the file of secondary memory
   by performing single write operation is called Pickiling.
==>Pickling concept participates in Write Operations.
------------------------------------
Steps for implementing Pickling:
-----------------------------------
==>Import Pickling Module, here pickle is one of the pre-definrd module.
==>Choose the file name and open it into write mode
==>Create an object with collection of values(Iterable Object)
==>Use the dump() of Pickle module. dump() save the content any object into the file with single write Operation.

  Syntax :   pickle.dump(object,filepointer)
  NOTE: That Pickling concept always takes the file in Binary Format
-----------------------------------------------------------------------------------------------------------------
-----------------
Un-Pickling:
-----------------
==>Let us assume there exist an object which multiple values in a file osf secondary memory.To read or transfer the
   entire record content from file of secondary memory by using read() and read(no. of chars), readline(),readlines()
   then they record values in the form of value by value and it is one of the time consuming process(multiple read operations).
   TO overcome this time consuming process, we must use the concept of Un-Pickling.
==>The Advantage of Un-Pickling concept is that with single read operation , we can read entire record content from the
   file of secondary memory into the object of main memory
-----------------
Definition of Un-Pickling:
---------------------------
==>The Process of reading or transfering entire record content from file of secondary memory into object of main memory
   by performing single write operation is called Un-Pickiling.
==>Un-Pickling concept participates in read Operations.
------------------------------------
Steps for implementing Un-Pickling:
-----------------------------------
==>Import Pickle Module, here pickle is one of the pre-definrd module.
==>Choose the file name and open it into read mode.
==>use the load() of pickle module. load() is used for tranfering or loading the entire record content from file
   of secondary memory into the object of main memory

  Syntax : objname = pickle.load(filepointer)
  NOTE : That Un-Pickling concept always takes the file in Binary Format
  
"""