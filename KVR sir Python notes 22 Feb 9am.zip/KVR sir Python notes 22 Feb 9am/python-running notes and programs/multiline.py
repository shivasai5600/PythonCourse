# -*- coding: utf-8 -*-
"""
Created on Sat Jun 12 17:04:33 2021

@author: Kiran
"""

str='''this is line 1
this is line 2
this is line 3
this is line 4'''
       
line3 = str.splitlines()[0]
print(line3)

