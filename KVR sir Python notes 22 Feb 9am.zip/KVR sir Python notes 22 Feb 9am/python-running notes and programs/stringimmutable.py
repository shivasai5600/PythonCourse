# -*- coding: utf-8 -*-
"""
Created on Fri Jun 11 17:04:26 2021

@author: Kiran
"""

str="hello"
str1=str.replace('h','a')
print('the object ',str,'is at :', id(str))
print('the object ',str1,'is at :', id(str1))