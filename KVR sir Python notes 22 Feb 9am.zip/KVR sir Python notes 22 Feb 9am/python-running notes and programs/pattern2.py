# -*- coding: utf-8 -*-
"""
Created on Thu Jun 10 16:30:39 2021

@author: Kiran
"""

n=4
for i in range(n):
   print((' '*(n-i-1))+('* ')*(i+1))