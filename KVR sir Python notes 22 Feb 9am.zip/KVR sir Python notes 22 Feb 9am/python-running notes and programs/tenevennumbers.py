# -*- coding: utf-8 -*-
"""
Created on Tue Jun  8 16:54:47 2021

@author: Kiran
"""

for value in range(20):
   if(value%2==0):
      print(value)