# -*- coding: utf-8 -*-
"""
Created on Thu Jun 10 16:40:21 2021

@author: Kiran
"""
n=4
counter=0
for i in range(n): 
    for j in range(i+1):
        counter=counter+1
        print(counter,end=" ")
    print()




