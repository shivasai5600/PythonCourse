# -*- coding: utf-8 -*-
"""
Created on Sun Jun  6 16:28:02 2021

@author: Kiran
"""

#def division(a,b):
#         return a/b
#print(division(200,100))
#print(division(100,200))
#print(division(a=200,b=100))
#print(division(b=100,a=200))

def division(a,b=50):
     return a/b
 
print(division(300,150))
print(division(300))
