#write a program for listing files -------- listdir()

import os
try:
    fileslist=os.listdir("C:\\Users\\hpadmin\\Desktop\\pyhton_2025\\Files")
    print(type(fileslist))
    print("-"*50)
    print("File Names:")
    print("-" * 50)
    for file in fileslist:
        print("{}".format(file))
    print("-" * 50)
    print("Number of Files in the Lists:{}".format(len(fileslist)))
    print("-" * 50)
except FileNotFoundError:
    print("No file exists")

#---------------------------------------------------------------------------------------------
print("="*100)

import os
try:
    fileslist=os.listdir(".")  #here it will give current working Folder in 'OS_Module'
    print(type(fileslist))
    print("-"*50)
    print("File Names:")
    print("-" * 50)
    for file in fileslist:
        print("{}".format(file))
    print("-" * 50)
    print("Number of Files in the Lists:{}".format(len(fileslist)))
    print("-" * 50)
except FileNotFoundError:
    print("No file exists")