# import os
# #here it will create new folder in 'C' drive newly with name 'ss',only for 1 time
# # Correct local path on Windows
# os.mkdir("C:\\ss")
# # OR use a raw string
# # os.mkdir(r"C:\ss")
# print("Folder is created successfully")

# # 2nd time excecution of same code
# import os
# try:
#     os.mkdir("C:\\ss")               #here it will gives exception of FileExsitError
#     print("folder is created successfuly")
# except FileExistsError:
#     print("File Already Exsists!")

# # 3nd time excecution of same code
# import os
# try:
#     os.mkdir("C:\\ss\\sone")               #here it will create sub folder
#     print("folder is created successfuly")
# except FileExistsError:
#     print("File Already Exsists!")

# 4th time excecution of same code
import os
try:
    os.mkdir("C:\\sd\\one\\sf\\ersd")               #here it will gives FileNotFoundError
    print("folder is created successfuly")
except FileNotFoundError:
    print("We can't create Root, sub or sub-sub folders")