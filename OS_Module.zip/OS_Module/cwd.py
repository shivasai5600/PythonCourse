#Program for obtaining current working folder/directory
import os
fname=os.getcwd()
print("corrent working folder name",fname)