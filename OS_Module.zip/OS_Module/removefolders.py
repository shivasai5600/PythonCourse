#write a program for to remove a folders/directories -------- removedirs()

# import os
# try:
#     os.removedirs("C:\\sy\\hyd\\pi1")                 #here 'C:\\sy\\hyd\\pi1' folders is not there,gives exception FNFE
#     print("Folder is Removed Successfully")
# except FileNotFoundError:
#     print("No folder exists")
# except OSError:
#     print("The Folders are not empty")


# import os
# try:
#     os.removedirs("C:\\sy\\hyd")                #here 'C:\\sy\\hyd' folders are not empty,gives exception OSError
#     print("Folder is Removed Successfully")
# except FileNotFoundError:
#     print("No folder exists")
# except OSError:
#     print("The Folders are not empty")


import os
try:
    os.removedirs("C:\\sy\\hyd\\pi")                 #here 'C:\\sy\\hyd\\pi' entire folders are removed
    print("Folder is Removed Successfully")
except FileNotFoundError:
    print("No folder exists")
except OSError:
    print("The Folders are not empty")

# If the above code executes again it throws FileNotFoundError