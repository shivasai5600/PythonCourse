#write a program for to rename a folder/directory -------- rename()

import os
try:
    os.rename("C:\\milk1","C:\\mild")
    print("Folder is Renamed Successfully")
except FileNotFoundError:
    print("No folder exists")


import os
try:
    os.rename("C:\\milk","C:\\mild")
    print("Folder is Renamed Successfully")
except FileNotFoundError:
    print("No folder exists")

