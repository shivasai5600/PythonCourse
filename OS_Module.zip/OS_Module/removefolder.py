#write a program for to remove a folder/directory -------- rmdir()

# import os
# try:
#     os.rmdir("C:\\ss\\sone")                 #here '\\sone' folder is removed
#     print("Folder is Removed Successfully")
# except FileNotFoundError:
#     print("No folder exists")
# except OSError:
#     print("Folder not exists")
#------------------------------------ 2nd time executing same code, exception giving bcz no 'sone' folder
# import os
# try:
#     os.rmdir("C:\\ss\\sone")                 #here '\\sone' folder is removed
#     print("Folder is Removed Successfully")
# except FileNotFoundError:
#     print("No folder exists")
# except OSError:
#     print("Folder not exists")

#-------------------------------3rd time executing code,with 'ss' folder bcz it is empty
# import os
# try:
#     os.rmdir("C:\\ss")                 #here '\\sone' folder is removed
#     print("Folder is Removed Successfully")
# except FileNotFoundError:
#     print("No folder exists")
# except OSError:
#     print("Folder not exists")

#------------------------------ 4th time executing code,with 'ss' folder bcz it gives exception
import os
try:
    os.rmdir("C:\\ss")                 #here '\\sone' folder is removed
    print("Folder is Removed Successfully")
except FileNotFoundError:
    print("No folder exists")
except OSError:
    print("Folder is not empty")