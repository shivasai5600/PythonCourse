import os
#here it will create new folders in 'C' drive newly with name '\\sy\\hyd\\pi',only for 1 time
# Correct local path on Windows
os.makedirs("C:\\sy\\hyd\\pi")
# OR use a raw string
# os.mkdir(r"C:\ss")
print("Folders are created successfully")