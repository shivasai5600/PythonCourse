""" ====================================== OS - MODULE ===================================================

==>'os' is one of the pre-defined module
==>The purpose of 'os' module is that "To perform" certain Operating System Based Operations.
==>SOme of the OS based Operations are:

    1)Obtaining current working folder/Directory --------------- (getcwd())
    2)create a folder(or)Directory ----------------------------- (mkdir())
    3)create a folders(or)directories -------------------------- (makedirs())
    4)remove a folder(or)directories --------------------------- (rmdir())
    5)remover a folders(or)directories ------------------------- (removedirs())
    6)renaming folders ----------------------------------------- (rename())
    7)obtain the files in a folder.......etc ------------------- (listdir())

---------------------------------------------------------------------------------------------------------------------
1)Obtaining current working folder/Directory :

=>For obtaining current working folder/directory ,we use getcwd()
Syntax :   varnmae=os.getcwd()

--------------------------------------------------------------------------------------------------------------------
2)create a folder(or)Directory :

=> To create a folder/directory,we use mkdir()
Syntax :    os.mkdir("folder name")

==>This function can create only one folder at a time but not able to create multiple folders
==>If the folder already exists and if we create then we get FileExsistError

---------------------------------------------------------------------------------------------------------------------
 3)create a folders(or)directories :

 ==>To create folders at a time, we use makedirs()
 ==>Syntax :  os.makedirs("folers Hierarchy")
 ==>Here folders Hierarchy represents Root Folder, Sub folder, sub-sub folders etc
 ==>If Folders Hierarchy already exsists and if we create again then we get FileExsitError.

--------------------------------------------------------------------------------------------------------------------
4)remove a folder(or)directories :

==>To remove a folder, we use rmdir()
==>Syntax :  os.rmdir("folder name")
==>This Function can remove one folder at a time but not able to remove Folders Hierarchy

---------------------------------------------------------------------------------------------------------------------
5)remover a folders(or)directories :

==>To remove folders Hierarchy, we use removedirs()
==> Syntax  :  os.removedirs("Folders Hierarchy")
==>Folders Hierarchy represents Root Folder, Sub Folder, sub-sub Folders etc
==>If Folders Hierarchy contains files then we get OSError
==>If folders Hierarchy does not exist then we get FileNotFoundError

--------------------------------------------------------------------------------------------------------------------
6)renaming folders :

==>TO Rename a folder, we use rename()
==>Syntax  : os.rename("Old Folder Name path","New Folder Name path")
==>If old folder name does not exist then we get FileNotFoundError.
==>If old folder name exists then Old Folder Name replaced with New Folder Name

---------------------------------------------------------------------------------------------------------------------
7)obtain the files in a folder.......etc :

==>To obtain the files in a folder, we use listdir()
==> Syntax  :  os.listdir("folder name")
"""